<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .card {
            padding: 20px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h2 class="text-center">Welcome to Admin Dashboard</h2>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>

        <?php if ($_SESSION['role'] == 'admin'): ?>
        <div class="card">
            <h3>Add Product</h3>
            <!-- Add Product Form -->
            <?php require 'add_product.php'; ?>
        </div>
        <div class="card">
            <h3>Delete Product</h3>
            <!-- Delete Product Form -->
            <?php require 'delete_product.php'; ?>
        </div>
        <div class="card">
            <h3>Update Product</h3>
            <!-- Update Product Form -->
            <?php require 'update_product.php'; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
