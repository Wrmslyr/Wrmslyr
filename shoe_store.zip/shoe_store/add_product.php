<?php
if ($_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $stmt = $pdo->prepare('INSERT INTO products (name, description, price) VALUES (?, ?, ?)');
    if ($stmt->execute([$name, $description, $price])) {
        echo 'Product added successfully';
    } else {
        echo 'Failed to add product';
    }
}
?>

<form method="POST">
    <input type="text" name="name" placeholder="Product Name" required>
    <textarea name="description" placeholder="Product Description" required></textarea>
    <input type="number" step="0.01" name="price" placeholder="Product Price" required>
    <button type="submit" name="add_product">Add Product</button>
</form>
