<?php
if ($_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    $stmt = $pdo->prepare('DELETE FROM products WHERE id = ?');
    if ($stmt->execute([$id])) {
        echo 'Product deleted successfully';
    } else {
        echo 'Failed to delete product';
    }
}
?>

<form method="POST">
    <input type="number" name="id" placeholder="Product ID" required>
    <button type="submit" name="delete_product">Delete Product</button>
</form>
