<?php
session_start();
if ($_SESSION['role'] != 'customer') {
    header('Location: login.php');
    exit;
}
require 'db.php';
?>

<h1>Customer Dashboard</h1>
<h2>Products</h2>
<?php
$stmt = $pdo->query('SELECT * FROM products');
while ($row = $stmt->fetch()) {
    echo '<div>';
    echo '<h3>' . $row['name'] . '</h3>';
    echo '<p>' . $row['description'] . '</p>';
    echo '<p>$' . $row['price'] . '</p>';
    echo '<form method="POST" action="add_to_cart.php">';
    echo '<input type="hidden" name="product_id" value="' . $row['id'] . '">';
    echo '<button type="submit">Add to Cart</button>';
    echo '</form>';
    echo '</div>';
}
?>
<a href="logout.php">Logout</a>
