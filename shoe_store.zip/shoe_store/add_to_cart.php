<?php
session_start();
if ($_SESSION['role'] != 'customer') {
    header('Location: login.php');
    exit;
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];

    $stmt = $pdo->prepare('INSERT INTO cart (user_id, product_id) VALUES (?, ?)');
    if ($stmt->execute([$user_id, $product_id])) {
        echo 'Product added to cart';
    } else {
        echo 'Failed to add product to cart';
    }
}
?>
