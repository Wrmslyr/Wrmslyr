<?php
if ($_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $stmt = $pdo->prepare('UPDATE products SET name = ?, description = ?, price = ? WHERE id = ?');
    if ($stmt->execute([$name, $description, $price, $id])) {
        echo 'Product updated successfully';
    } else {
        echo 'Failed to update product';
    }
}
?>

<form method="POST">
    <input type="number" name="id" placeholder="Product ID" required>
    <input type="text" name="name" placeholder="Product Name" required>
    <textarea name="description" placeholder="Product Description" required></textarea>
    <input type="number" step="0.01" name="price" placeholder="Product Price" required>
    <button type="submit" name="update_product">Update Product</button>
</form>
